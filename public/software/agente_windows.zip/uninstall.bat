@echo off
cd /d "%~dp0"

REM Verificar permisos de administrador
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo [ERROR] Este script requiere permisos de Administrador
    echo Clic derecho en uninstall.bat ^> Ejecutar como administrador
    pause
    exit /b 1
)

echo.
echo ============================================
echo  DESINSTALADOR - Print Agent v2.0
echo ============================================
echo.

REM ==========================================
REM 1. Detener proceso
REM ==========================================
echo [*] Deteniendo Print Agent...
taskkill /f /im print-agent.exe >nul 2>&1
echo [OK] Proceso detenido

REM ==========================================
REM 2. Eliminar servicio antiguo si existe
REM ==========================================
sc query PrintAgent >nul 2>&1
if %errorlevel% equ 0 (
    net stop PrintAgent >nul 2>&1
    sc delete PrintAgent >nul 2>&1
    echo [OK] Servicio Windows eliminado
)

REM ==========================================
REM 3. Eliminar inicio automatico
REM ==========================================
echo [*] Eliminando inicio automatico...
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "PrintAgent" /f >nul 2>&1
del /f /q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\PrintAgent.vbs" >nul 2>&1
del /f /q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\PrintAgent.lnk" >nul 2>&1
echo [OK] Inicio automatico eliminado

REM ==========================================
REM 4. Eliminar protocolo print://
REM ==========================================
echo [*] Eliminando protocolo print://...
reg delete "HKEY_CLASSES_ROOT\print" /f >nul 2>&1
echo [OK] Protocolo eliminado

echo.
echo ============================================
echo  DESINSTALACION COMPLETADA
echo ============================================
echo.
echo [OK] Print Agent desinstalado completamente
echo.
echo Para reinstalar: ejecutar install.bat como administrador
echo.
echo ============================================
echo.
pause
