@echo off
cd /d "%~dp0"
setlocal enabledelayedexpansion

REM Verificar permisos de administrador
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo [ERROR] Este script requiere permisos de Administrador
    echo Clic derecho en install.bat ^> Ejecutar como administrador
    pause
    exit /b 1
)

echo.
echo ============================================
echo  INSTALADOR - Print Agent v2.0
echo  Agente de impresion ESC/POS
echo ============================================
echo.

set "INSTALL_DIR=%~dp0"
if "%INSTALL_DIR:~-1%"=="\" set "INSTALL_DIR=%INSTALL_DIR:~0,-1%"
set "AGENT_PATH=%INSTALL_DIR%\print-agent.exe"
set "VBS_PATH=%INSTALL_DIR%\start-silent.vbs"

REM Verificar que el ejecutable existe
if not exist "!AGENT_PATH!" (
    echo.
    echo [ERROR] No se encontro print-agent.exe en: !INSTALL_DIR!
    echo Asegurate de copiar print-agent.exe junto a este script.
    pause
    exit /b 1
)

REM ==========================================
REM 1. Detener instancia anterior si existe
REM ==========================================
echo [*] Deteniendo instancias anteriores...
taskkill /f /im print-agent.exe >nul 2>&1
sc query PrintAgent >nul 2>&1
if %errorlevel% equ 0 (
    net stop PrintAgent >nul 2>&1
    sc delete PrintAgent >nul 2>&1
    timeout /t 2 /nobreak >nul
    echo [OK] Servicio anterior eliminado
)
REM Limpiar entrada Run anterior si existe
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "PrintAgent" /f >nul 2>&1

echo.

REM ==========================================
REM 2. Registrar protocolo print://
REM ==========================================
echo [*] Registrando protocolo print:// ...
reg add "HKEY_CLASSES_ROOT\print" /ve /d "URL:Print Protocol" /f >nul 2>&1
reg add "HKEY_CLASSES_ROOT\print" /v "URL Protocol" /d "" /f >nul 2>&1
reg add "HKEY_CLASSES_ROOT\print\shell\open\command" /ve /d "\"!AGENT_PATH!\" \"%%1\"" /f >nul 2>&1
reg add "HKEY_CLASSES_ROOT\print" /v "EditFlags" /t REG_DWORD /d 2 /f >nul 2>&1
echo [OK] Protocolo print:// registrado

echo.

REM ==========================================
REM 3. Inicio automatico con Windows (Startup shortcut)
REM ==========================================
echo [*] Configurando inicio automatico...
set "STARTUP_DIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
REM Limpiar entradas anteriores
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "PrintAgent" /f >nul 2>&1
del /f /q "!STARTUP_DIR!\PrintAgent.vbs" >nul 2>&1
del /f /q "!STARTUP_DIR!\PrintAgent.lnk" >nul 2>&1
REM Crear shortcut .lnk via PowerShell (sin problemas de escape, sin copiar el VBS)
powershell -NoProfile -Command "$ws = New-Object -ComObject WScript.Shell; $lnk = $ws.CreateShortcut('!STARTUP_DIR!\PrintAgent.lnk'); $lnk.TargetPath = 'wscript.exe'; $lnk.Arguments = '//nologo \"!VBS_PATH!\"'; $lnk.WorkingDirectory = '!INSTALL_DIR!'; $lnk.WindowStyle = 7; $lnk.Description = 'Print Agent inicio silencioso'; $lnk.Save()" >nul 2>&1
if exist "!STARTUP_DIR!\PrintAgent.lnk" (
    echo [OK] Se iniciara automaticamente al iniciar sesion (sin ventana)
) else (
    echo [WARNING] No se pudo crear el acceso directo en Startup
)

echo.

REM ==========================================
REM 4. Excepcion en Windows Defender
REM ==========================================
echo [*] Configurando excepcion en Windows Defender...
powershell -Command "Add-MpPreference -ExclusionPath '!AGENT_PATH!' -ErrorAction SilentlyContinue" >nul 2>&1
echo [OK] Excepcion configurada

echo.

REM ==========================================
REM 5. Iniciar ahora
REM ==========================================
echo [*] Iniciando Print Agent...
wscript //nologo "!VBS_PATH!"
timeout /t 3 /nobreak >nul

REM Verificar que esta corriendo
powershell -Command "try { $r = Invoke-WebRequest -Uri 'http://localhost:9876/api/status' -UseBasicParsing -TimeoutSec 3; if($r.StatusCode -eq 200){'[OK] Print Agent corriendo en puerto 9876'}else{'[WARNING] Respuesta inesperada'} } catch { '[WARNING] No responde aun, espera unos segundos' }"

echo.

REM ==========================================
REM 6. Informacion final
REM ==========================================
echo ============================================
echo  INSTALACION COMPLETADA
echo ============================================
echo.
echo [OK] Print Agent instalado y corriendo
echo [OK] Inicio automatico con Windows (sin ventana)
echo [OK] Protocolo print:// registrado
echo.
echo   Panel: http://localhost:9876
echo   API:   http://localhost:9876/api/print/ticket
echo.
echo Para detener:  taskkill /f /im print-agent.exe
echo Para iniciar:  wscript //nologo "%VBS_PATH%"
echo Startup:       %APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\PrintAgent.vbs
echo.
echo ============================================
echo.
pause
