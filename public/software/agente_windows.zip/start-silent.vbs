Dim sDir
sDir = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)

' Verificar que no este ya corriendo
Dim oShell : Set oShell = CreateObject("WScript.Shell")
Dim oExec  : Set oExec  = oShell.Exec("tasklist /FI ""IMAGENAME eq print-agent.exe"" /NH")
Dim sOut   : sOut = oExec.StdOut.ReadAll()
If InStr(sOut, "print-agent.exe") > 0 Then
    WScript.Quit 0
End If

oShell.CurrentDirectory = sDir
oShell.Run """" & sDir & "\print-agent.exe""", 0, False
