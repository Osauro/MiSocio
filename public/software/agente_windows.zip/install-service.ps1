# Instalar como Servicio Windows
# Ejecutar como Administrador: powershell -ExecutionPolicy Bypass -File install-service.ps1

$serviceName = "PrintAgent"
$displayName = "Print Agent"
$scriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
$exePath = Join-Path $scriptPath "print-agent.exe"

Write-Host "Print Agent - Instalador de Servicio" -ForegroundColor Cyan

# Verificar si existe el ejecutable
if (-not (Test-Path $exePath)) {
    Write-Host "ERROR: No se encontro print-agent.exe" -ForegroundColor Red
    exit 1
}

# Verificar si ya existe el servicio
$svc = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
if ($svc) {
    Write-Host "El servicio ya existe. Deteniendo..." -ForegroundColor Yellow
    Stop-Service -Name $serviceName -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 2
    Remove-Service -Name $serviceName -Force
    Start-Sleep -Seconds 2
}

Write-Host "Instalando servicio $displayName..." -ForegroundColor Green

# Crear servicio con NSSM (recomendado) o con sc.exe
$nssm = "C:\Program Files\nssm\win64\nssm.exe"

if (Test-Path $nssm) {
    # Usar NSSM si esta disponible
    & $nssm install $serviceName $exePath
    & $nssm set $serviceName AppDirectory $scriptPath
    & $nssm set $serviceName AppStdout "$scriptPath\logs\stdout.log"
    & $nssm set $serviceName AppStderr "$scriptPath\logs\stderr.log"
    & $nssm set $serviceName AppNoConsole 1
    & $nssm set $serviceName AppPriority BELOW_NORMAL_PRIORITY_CLASS
    & $nssm start $serviceName
    Write-Host "Servicio instalado y iniciado con NSSM" -ForegroundColor Green
} else {
    # Crear con sc.exe
    sc.exe create $serviceName binPath= "`"$exePath`"" start= auto DisplayName= "`"$displayName`""
    Write-Host "Servicio creado con sc.exe" -ForegroundColor Green
    
    # Configurar servicio para no mostrar ventana (usar reg.exe para modificar registry)
    reg add "HKLM\SYSTEM\CurrentControlSet\Services\$serviceName" /v Type /t REG_DWORD /d 16 /f | Out-Null
    
    Start-Service -Name $serviceName
    Write-Host "Servicio iniciado" -ForegroundColor Green
}

# Crear carpeta de logs
$logPath = Join-Path $scriptPath "logs"
if (-not (Test-Path $logPath)) {
    New-Item -ItemType Directory -Path $logPath | Out-Null
}

# Registrar protocolo print:// en el Registro de Windows
Write-Host ""
Write-Host "Registrando protocolo print://..." -ForegroundColor Green

try {
    $regPath = "HKCU:\Software\Classes\print"
    $cmdPath = "$regPath\shell\open\command"
    
    # Crear estructura de claves si no existen
    if (-not (Test-Path $regPath)) {
        New-Item -Path $regPath -Force | Out-Null
    }
    if (-not (Test-Path "$regPath\shell")) {
        New-Item -Path "$regPath\shell" -Force | Out-Null
    }
    if (-not (Test-Path "$regPath\shell\open")) {
        New-Item -Path "$regPath\shell\open" -Force | Out-Null
    }
    if (-not (Test-Path $cmdPath)) {
        New-Item -Path $cmdPath -Force | Out-Null
    }
    
    # Establecer valores del protocolo
    Set-ItemProperty -Path $regPath -Name "(Default)" -Value "URL:print Protocol" -Force
    Set-ItemProperty -Path $regPath -Name "URL Protocol" -Value "" -Force
    Set-ItemProperty -Path "$regPath\shell\open" -Name "(Default)" -Value "" -Force
    Set-ItemProperty -Path $cmdPath -Name "(Default)" -Value "`"$exePath`" `"%1`"" -Force
    
    Write-Host "Protocolo print:// registrado correctamente" -ForegroundColor Green
} catch {
    Write-Host "ADVERTENCIA: No se pudo registrar el protocolo print://" -ForegroundColor Yellow
    Write-Host "Error: $_" -ForegroundColor Yellow
    Write-Host "Puedes hacerlo manualmente importando print-protocol.reg" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "INSTALACION COMPLETADA" -ForegroundColor Green
Write-Host "Servicio: $serviceName" -ForegroundColor Cyan
Write-Host "UI disponible en: http://localhost:9876" -ForegroundColor Cyan
Write-Host "Protocolo: print://" -ForegroundColor Cyan
Write-Host "Modo: Oculto sin ventanas" -ForegroundColor Cyan
Write-Host ""
Write-Host "Comandos utiles:" -ForegroundColor Yellow
Write-Host "  Iniciar:   Start-Service -Name $serviceName" -ForegroundColor White
Write-Host "  Detener:   Stop-Service -Name $serviceName" -ForegroundColor White
Write-Host "  Estado:    Get-Service -Name $serviceName" -ForegroundColor White
Write-Host "  Desinstalar: Remove-Service -Name $serviceName" -ForegroundColor White
